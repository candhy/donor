package com.cg.donar.exception;

public class DonorException extends Exception {
	
	public DonorException (String message)
	{
		super(message);
	}
	

}
