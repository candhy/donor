package com.cg.pod.service;

public interface PetServiceInterface 
{
	void add1(String str);
	void delete();
	void update();
	void viewAll();
}
