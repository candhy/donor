package com.cg.pod.service;
public interface PetServiceInterface 
{
	
		void add();
		void delete();
		void update();
		void viewAll();
	

}
